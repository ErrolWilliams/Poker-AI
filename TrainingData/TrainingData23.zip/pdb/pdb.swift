swift     857269257  7  2 Bk  k     k     k         9441   10    0 7s 2h
swift     857269298  6  1 Brc brc   kc    kf        9431   90    0 
swift     857269370  6  6 f   -     -     -         9341    0    0 
swift     857269405  6  5 f   -     -     -         9341    0    0 
swift     857269463  7  5 f   -     -     -         9341    0    0 
swift     857269522  9  4 f   -     -     -         9341    0    0 
swift     857269592  9  3 rr  r     b     b         9341  100  320 Kh Kd
swift     857269664  8  2 Bk  f     -     -         9561   10    0 
swift     857269727  7  1 Bc  kf    -     -         9551   10    0 
swift     857269785  7  7 f   -     -     -         9541    0    0 
swift     857269814  7  6 f   -     -     -         9541    0    0 
swift     857269864  7  5 KQ  -     -     -         9541    0    0 
swift     857274104  4  3 f   -     -     -         9406    0    0 
swift     857274121  5  2 Bk  bc    rrc   c         9406  150    0 3s 3c
swift     857274176  4  1 Bc  b     -     -         9256   20   30 
swift     857274202  4  4 c   k     f     -         9266   10    0 
swift     857274237  4  3 c   b     -     -         9256   20   35 
swift     857274253  4  2 Br  kc    k     k         9271   40    0 2s 4d
swift     857274292  4  1 Bc  k     k     kf        9231   20    0 
swift     857274327  4  4 cc  r     b     b         9211   80  240 8h 5h
swift     857274416  5  4 f   -     -     -         9371    0    0 
swift     857274463  5  3 c   b     -     -         9371   20   40 
swift     857274488  5  2 Bk  kf    -     -         9391   10    0 
swift     857274547  5  1 Br  -     -     -         9381   20   30 
swift     857274566  5  5 r   b     b     k         9391   50  115 Ah 6c
swift     857274612  6  5 f   -     -     -         9456    0    0 
swift     857274666  6  4 f   -     -     -         9456    0    0 
swift     857274713  6  3 c   b     -     -         9456   20   45 
swift     857274745  6  2 Bf  -     -     -         9481   10    0 
swift     857274794  6  1 Bc  kf    -     -         9471   10    0 
swift     857274825  6  6 f   -     -     -         9461    0    0 
swift     857274883  7  6 c   b     f     -         9461   20    0 
swift     857274935  6  4 c   r     b     k         9441   50    0 Ac 8h
swift     857274969  5  2 r   k     kc    kc        9391   60    0 7s 7c
swift     857275014  5  2 Bk  k     k     k         9331   10    0 7h 2c
swift     857275046  5  1 Br  kc    kf    -         9321   30    0 
swift     857275074  5  5 f   -     -     -         9291    0    0 
swift     857275098  5  4 f   -     -     -         9291    0    0 
swift     857275139  5  3 f   -     -     -         9291    0    0 
swift     857275183  5  2 Bc  k     b     -         9291   40   65 
swift     857275233  5  1 Bc  b     kf    -         9316   30    0 
swift     857275267  4  4 f   -     -     -         9286    0    0 
swift     857275323  4  3 f   Q     -     -         9286    0    0 
swift     857276856  8  4 r   rc    kc    kc        9286   90  235 Ad As
swift     857276913  8  3 f   -     -     -         9431    0    0 
swift     857276984  8  2 Bc  kcc   kc    kf        9431   70    0 
swift     857277070  9  1 Bf  -     -     -         9361    5    0 
swift     857277146  9  9 f   -     -     -         9356    0    0 
swift     857277212  9  8 cc  c     f     -         9356   40    0 
swift     857277299  9  8 f   -     Q     -         9316    0    0 
swift     857619263  9  4 f   -     -     -         8286    0    0 
swift     857619426  8  3 f   -     -     -         8286    0    0 
swift     857619551  8  2 Bk  krc   kc    kf        8286   60    0 
swift     857619741  8  1 BfQ -     -     -         8226    5    0 
swift     857700105 10  3 r   b     -     -         8221   30  110 
swift     857700165 10  3 f   -     -     -         8301    0    0 
swift     857700215 10  2 Bc  c     f     -         8301   30    0 
swift     857700269 10  1 Br  kr    br    b         8271  130  370 As Qs
swift     857700337 10 10 cc  k     f     -         8511   40    0 
swift     857700398  9  3 Q   -     -     -         8471    0    0 
swift     857801702  5  3 f   -     -     -         8471    0    0 
swift     857801825  5  2 Bk  kc    k     k         8471   20    0 Jh Qd
swift     857801876  5  1 Bf  -     -     Q         8451    5    0 
swift     857806652  5  3 f   -     -     -         8446    0    0 
swift     857806690  4  2 Bk  kc    b     b         8446   60  130 Td 8c
swift     857806720  4  1 Bcc kf    -     -         8516   20    0 
swift     857806752  4  4 f   -     -     -         8496    0    0 
swift     857806782  4  3 f   -     -     -         8496    0    0 
swift     857806804  4  2 Bc  f     -     -         8496   20    0 
swift     857806852  4  1 Bc  b     k     k         8476   30    0 Qh 9s
swift     857806875  4  4 f   -     -     -         8446    0    0 
swift     857806896  4  3 f   -     -     -         8446    0    0 
swift     857806937  4  2 Brc b     b     c         8446   90  180 5h Kd
swift     857806962  5  1 Bc  k     kf    -         8536   10    0 
swift     857807020  5  5 f   -     -     -         8526    0    0 
swift     857807056  5  4 f   -     -     -         8526    0    0 
swift     857807085  4  3 cf  -     -     -         8526   10    0 
swift     857807139  4  2 Bc  k     k     f         8516   20    0 
swift     857807177  4  1 Bc  k     kf    -         8496   10    0 
swift     857807213  4  4 f   -     -     -         8486    0    0 
swift     857807227  4  3 f   -     -     -         8486    0    0 
swift     857807258  4  2 Br  b     b     k         8486   60  220 Ac 3c
swift     857807303  3  1 Bc  kf    -     -         8646   10    0 
swift     857807329  3  3 rc  f     -     -         8636   30    0 
swift     857807348  3  2 Bc  k     b     b         8606   60  160 Qh Jh
swift     857807381  3  1 Bf  -     -     -         8706    5    0 
swift     857807392  3  3 rc  r     b     k         8701   70    0 Kc 8h
swift     857807414  3  2 Bk  kc    cc    k         8631   60  180 8c 6s
swift     857807452  3  1 Br  b     -     -         8751   30   70 
swift     857807476  3  3 r   b     b     b         8791   70  160 2h Ah
swift     857807503  3  2 Bf  -     -     -         8881   10    0 
swift     857807514  3  1 Bf  -     -     -         8871    5    0 
swift     857807543  3  3 r   b     b     f         8866   50    0 
swift     857807584  3  2 Bf  -     -     -         8816   10    0 
swift     857807611  3  1 Bc  kf    -     -         8806   20    0 
swift     857807627  3  3 cc  b     -     -         8786   30   70 
swift     857807656  3  2 Bc  k     b     b         8826   60  160 2d Jc
swift     857807680  3  1 Bf  -     -     -         8926    5    0 
swift     857807687  3  3 f   -     -     -         8921    0    0 
swift     857807694  3  2 Bk  k     k     k         8921   10    0 7s 6d
swift     857807713  3  1 Bc  b     b     b         8911   60  110 
swift     857807735  3  3 r   b     -     -         8961   30   55 
swift     857807751  3  2 Br  b     b     b         8986   70  160 Ad 4d
swift     857807777  3  1 Br  bf    -     -         9076   30    0 
swift     857807795  3  3 c   rc    r     b         9046  100  220 Qc 9c
swift     857807820  3  2 Bc  kc    kr    b         9166   90  250 Js 9h
swift     857807866  3  1 Brc bf    -     -         9326   40    0 
swift     857807881  3  3 cc  k     f     -         9286   20    0 
swift     857807904  3  2 Bf  -     -     -         9266   10    0 
swift     857807940  3  1 Bc  k     b     -         9256   30   50 
swift     857807956  3  3 f   -     -     -         9276    0    0 
swift     857807975  3  2 Bc  b     k     k         9276   30   40 Kc 9d
swift     857808000  3  1 Bc  kf    -     -         9286   10    0 
swift     857808019  3  3 r   b     b     b         9276   70  145 Qd Th
swift     857808052  3  2 Bc  bc    kc    kc        9351   80  165 4d 9h
swift     857808075  3  1 Bf  -     -     -         9436    5    0 
swift     857808103  3  3 f   -     -     -         9431    0    0 
swift     857808125  3  2 Bk  k     k     b         9431   30   45 
swift     857808141  3  1 Bcc kf    -     -         9446   20    0 
swift     857808166  3  3 r   b     -     -         9426   30   70 
swift     857808185  3  2 Brcc b     kc    kf        9466   70    0 
swift     857808232  3  1 Brc kc    krc   kc        9396  130    0 Kc Ah
swift     857808258  3  3 r   b     b     b         9266   70  145 Qh Jh
swift     857808288  3  2 Bc  k     b     br        9341  100  110 3c As
swift     857808347  3  1 Br  br    b     kc        9351   90    0 Kd 7c
swift     857808377  3  3 f   -     -     Q         9261    0    0 
swift     857808464  2  1 Bc  b     b     -         9261   40   60 
swift     857808476  2  2 Bf  -     -     -         9281   10    0 
swift     857808481  2  1 Bc  bc    krc   k         9271   90   90 9h 6s
swift     857808506  3  3 f   -     -     -         9271    0    0 
swift     857808520  3  2 r   b     b     bc        9271   90    0 Ah 2s
swift     857808549  3  2 Br  b     -     -         9181   30   50 
swift     857808568  3  1 Br  -     -     -         9201   20   30 
swift     857808577  3  3 f   -     -     -         9211    0    0 
swift     857808593  3  2 Bk  f     -     -         9211   10    0 
swift     857808607  3  1 Bf  -     -     -         9201    5    0 
swift     857808616  3  3 f   -     -     -         9196    0    0 
swift     857808633  3  2 Bk  k     kr    bf        9196   70    0 
swift     857808665  3  1 Bc  bc    kc    k         9126   50    0 6h 9d
swift     857808683  3  3 cc  b     c     f         9076   50    0 
swift     857808709  3  2 Br  bc    k     b         9026   60  125 Qh 4c
swift     857808728  3  1 Bc  b     b     -         9091   40   60 
swift     857808745  3  3 c   f     -     -         9111   10    0 
swift     857808756  2  2 Br  rrc   c     c         9101  120    0 Qd Qs
swift     857808779  2  1 Bc  k     b     -         8981   30   40 
swift     857808801  2  2 BQ  -     -     -         8991   10    0 
swift     857966912  9  4 f   -     -     -         8981    0    0 
swift     857966957 10  3 f   -     -     -         8981    0    0 
swift     857967020 11  2 Bk  kf    -     -         8981   10    0 
swift     857967172 10  1 Bc  k     kf    -         8971   10    0 
swift     857967257 12 12 f   -     -     -         8961    0    0 
swift     857967351 12 11 c   r     k     c         8961   60    0 Tc 9d
swift     857967417 12 10 c   f     -     -         8901   20    0 
swift     857967518 11  9 f   -     -     -         8881    0    0 
swift     857967598 12  8 c   c     c     c         8881   70    0 6d 7h
swift     857967697 12  8 r   rc    c     c         8811  100    0 Jd Td
swift     857967751 11  6 c   k     f     -         8711   10    0 
swift     857967815 11  4 f   -     Q     -         8701    0    0 
swift     859005419 12 11 f   -     -     -         3975    0    0 
swift     859005503 10  9 r   b     k     k         3975   30  100 Ad Ks
swift     859005567  8  7 f   -     -     -         4045    0    0 
swift     859005644  9  7 f   -     -     -         4045    0    0 
swift     859005783 10  7 c   b     b     k         4045   40   90 Jd Qd
swift     859005844 10  6 f   -     -     -         4095    0    0 
swift     859005939 11  5 f   -     -     -         4095    0    0 
swift     859006006 11  4 f   -     -     -         4095    0    0 
swift     859006075  9  3 f   -     -     -         4095    0    0 
swift     859006145 10  2 Bc  kf    -     -         4095   20    0 
swift     859006224  9  1 Bc  kc    kf    -         4075   20    0 
swift     859006278  9  9 f   -     -     -         4055    0    0 
swift     859006421 10  7 c   b     b     k         4055   40  140 8d Td
swift     859006509 11  7 f   -     -     -         4155    0    0 
swift     859006587 11  6 c   b     -     -         4155   20   60 
swift     859006664 11  5 c   k     r     -         4195   50  115 
swift     859006794  9  3 f   -     -     -         4260    0    0 
swift     859006835 11  2 Bf  -     -     -         4260   10    0 
swift     859006914 11  1 Bc  kr    bc    kc        4250   90  300 Qd Js
swift     859006986 11 11 c   b     k     f         4460   20    0 
swift     859007032 11 10 f   -     -     -         4440    0    0 
swift     859007132 11  9 f   -     -     -         4440    0    0 
swift     859007227 10  7 f   -     -     -         4440    0    0 
swift     859007277  8  5 f   -     -     -         4440    0    0 
swift     859007358  8  4 c   f     Q     -         4440   10    0 
