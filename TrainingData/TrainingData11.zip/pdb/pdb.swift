swift     826254447  7  4 f   -     -     -         1000    0    0 
swift     826254494  8  3 f   -     -     -         1000    0    0 
swift     826254594  8  2 Bk  k     b     kc        1000   50    0 6h 3c
swift     826254672  6  1 Bc  b     kc    k          950   40  120 2h Kd
swift     826254738  6  6 c   b     k     f         1030   20    0 
swift     826254785  5  4 c   b     b     k         1010   40  110 Kh Qs
swift     826254872  4  2 Br  k     b     c         1080   60  120 9d Td
swift     826254923  6  1 Bcf -     -     -         1140   10    0 
swift     826254976  6  6 f   -     -     -         1130    0    0 
swift     826255018  7  6 c   cc    kf    -         1130   30    0 
swift     826255121  8  6 f   -     -     -         1100    0    0 
swift     826255164  8  5 cc  b     k     k         1100   30    0 Tc Ah
swift     826255257 10  6 f   -     -     -         1070    0    0 
swift     826255332 10  5 r   c     f     -         1070   30    0 
swift     826255414 10  4 cc  fQ    -     -         1040   20    0 
swift     826255983 11  6 cc  r     br    brc       1020  180  218 Qc Ks
swift     826256088 12  5 cc  ccc   kf    -         1058   60    0 
swift     826256237 12  3 Q   -     -     -          998    0    0 
swift     826340922 10  8 f   -     -     -          998    0    0 
swift     826341115 10  7 f   -     -     -          998    0    0 
swift     826341364 10  6 f   -     -     -          998    0    0 
swift     826341482 10  5 f   -     -     -          998    0    0 
swift     826341564 12  4 f   -     -     -          998    0    0 
swift     826341739 12  3 ccc k     kc    kc         998   80    0 8h Tc
swift     826341972 12  2 Bf  -     -     -          918   10    0 
swift     826342152  9  1 Bc  kc    k     kc         908   50    0 Qs Ac
swift     826342341 10  9 f   -     -     -          858    0    0 
swift     826342509 10  8 c   cc    kc    c          858   80    0 Ac Th
swift     826342599  9  7 c   k     k     r          778   50   75 7s Js
swift     826342724  8  5 c   f     -     -          803   10    0 
swift     826342841  7  2 f   -     Q     -          793    0    0 
swift     826344895  8  4 f   -     -     -          793    0    0 
swift     826344994  8  2 Bk  k     kf    -          793   10    0 
swift     826345065  9  1 Bc  kf    -     -          783   20    0 
swift     826345183 10 10 c   f     -     -          763   10    0 
swift     826345285 10  9 f   -     -     -          753    0    0 
swift     826345369 10  8 cc  k     c     c          753   60  225 Qd Jc
swift     826345490 11  8 f   -     -     -          918    0    0 
swift     826345568 11  7 f   -     -     -          918    0    0 
swift     826345640 11  6 c   kf    -     -          918   10    0 
swift     826345706 11  7 fQ  -     -     -          908    0    0 
swift     826390464  7  6 c   f     -     -          908   10    0 
swift     826390531  7  5 f   -     -     -          898    0    0 
swift     826390605  6  4 f   -     -     -          898    0    0 
swift     826390643  6  3 f   -     -     -          898    0    0 
swift     826390679  6  2 Br  b     k     bc         898   70  180 As Ts
swift     826390731  6  1 Bc  kf    -     -         1008   10    0 
swift     826390790  6  6 f   -     -     -          998    0    0 
swift     826390833  7  5 c   f     -     -          998   10    0 
swift     826390898  8  5 f   -     -     -          988    0    0 
swift     826391002  8  4 f   -     -     -          988    0    0 
swift     826391051  7  3 f   -     -     -          988    0    0 
swift     826391105  7  2 Bf  -     -     -          988   10    0 
swift     826391133  7  1 Bc  kf    -     -          978   10    0 
swift     826391190  7  7 f   -     -     -          968    0    0 
swift     826391228  7  6 f   -     -     -          968    0    0 
swift     826391286  7  5 cc  kf    -     -          968   20    0 
swift     826391353  7  4 cc  f     -     -          948   20    0 
swift     826391396  7  3 c   f     -     -          928   10    0 
swift     826391461  8  2 Bk  k     k     b          918   30   50 
swift     826391504  8  1 Bcc kc    kc    b          938   90    0 Jc Th
swift     826391595  8  8 f   -     -     -          848    0    0 
swift     826391652  7  6 r   r     b     rr         848  140  470 9c 9h
swift     826391732  7  7 f   -     -     -         1178    0    0 
swift     826391883  5  4 r   b     bf    -         1178   50    0 
swift     826391970  6  3 f   -     -     -         1128    0    0 
swift     826392031  6  2 Bk  b     b     bc        1128   80    0 Jd Kc
swift     826392073  7  1 BfQ -     -     -         1048    5    0 
swift     826430327  9  3 f   -     -     -         1043    0    0 
swift     826430384  8  2 Bk  kf    -     Q         1043   10    0 
swift     826430694  9  7 f   -     -     -         1033    0    0 
swift     826430787 10  6 f   -     -     -         1033    0    0 
swift     826430883 10  5 f   -     -     -         1033    0    0 
swift     826430932  9  3 f   -     -     -         1033    0    0 
swift     826430994  9  2 Bk  b     k     c         1033   40   80 7s Jd
swift     826431043  9  1 Bc  kf    -     -         1073   10    0 
swift     826431175  9  9 f   Q     -     -         1063    0    0 
swift     826486354 10  8 f   -     -     -         1063    0    0 
swift     826486356  9  6 f   -     -     -         1063    0    0 
swift     826486374 10  6 f   -     -     -         1063    0    0 
swift     826486446 11  5 cc  f     -     -         1063   20    0 
swift     826486889 10  1 Bc  kf    -     -         1063   10    0 
swift     826486992  9  9 f   -     -     -         1053    0    0 
swift     826487082 10  9 f   -     -     -         1053    0    0 
swift     826487149  9  7 f   -     -     -         1053    0    0 
swift     826487202 10  7 c   c     r     b         1053   80    0 Td Ad
swift     826487346  9  6 r   c     c     k          973   50    0 Qs Qc
swift     826487471  8  3 c   k     bc    kc         923   70  103 Qs Td
swift     826487646  7  2 BQ  -     -     -          956   10    0 
swift     826595371  8  2 Bk  k     k     k          946   10    0 5h 8d
swift     826595425  7  1 Bf  -     -     -          936    5    0 
swift     826595466  7  7 f   -     -     -          931    0    0 
swift     826595513  7  6 f   -     -     -          931    0    0 
swift     826595560  7  5 f   -     -     -          931    0    0 
swift     826595593  7  4 c   b     -     -          931   20   35 
swift     826595627  7  3 f   -     -     -          946    0    0 
swift     826595673  7  2 Bk  k     kf    -          946   10    0 
swift     826595705  6  1 Bc  b     k     kc         936   40    0 Kh 7s
swift     826595772  6  6 r   f     -     -          896   20    0 
swift     826595808  6  5 c   b     b     -          876   50  110 
swift     826595853  7  4 c   bc    kc    kf         936   50    0 
swift     826595907  7  3 c   f     -     -          886   10    0 
swift     826595966  8  2 Bk  k     kf    -          876   10    0 
swift     826596023  8  1 Bc  bc    kc    kf         866   50    0 
swift     826596084  8  8 c   k     f     -          816   10    0 
swift     826596166  8  7 cc  c     f     -          806   40    0 
swift     826596233  8  6 c   k     c     k          766   30    0 Kc 8c
swift     826596351  9  6 r   b     b     b          736   70    0 Jc Js
swift     826596426  9  5 f   -     -     -          666    0    0 
swift     826596475  9  4 f   -     -     -          666    0    0 
swift     826596512  9  3 f   -     -     -          666    0    0 
swift     826596565  9  2 Bc  kc    kcf   -          666   70    0 
swift     826596647  9  1 Bc  kf    -     -          596   20    0 
swift     826596703  9  9 KQ  -     -     -          576    0    0 
swift     826768848  7  6 c   b     -     -          576   20   50 
swift     826768930 10  6 f   -     -     -          606    0    0 
swift     826769043 10  5 c   r     b     b          606   70  210 Jc Qh
swift     826769121 11  4 c   k     rc    r          746  110  160 Qh Js
swift     826769227 12  3 fQ  -     -     -          796    0    0 
swift     826851067  7  2 Bk  k     kf    -          796   10    0 
swift     826851132  7  1 Bf  -     -     -          786    5    0 
swift     826851185  7  7 c   f     -     -          781   10    0 
swift     826851242  7  6 f   -     -     -          771    0    0 
swift     826851344  7  5 c   k     b     f          771   30    0 
swift     826851422  6  3 cc  kc    kf    -          741   30    0 
swift     826851483  6  3 f   -     -     -          711    0    0 
swift     826851576  8  2 Br  bf    -     -          711   30    0 
swift     826851658  8  1 Bc  kf    -     -          681   10    0 
swift     826851717  7  7 c   f     -     -          671   20    0 
swift     826851767 10  8 c   r     c     k          651   50    0 Ah Td
swift     826851861 11  8 c   c     f     -          601   20    0 
swift     826852002 11  7 cc  kc    cc    k          581   70  260 7h 7s
swift     826852141 12  8 c   c     f     -          771   20    0 
swift     826852198 11  6 f   -     -     -          751    0    0 
swift     826852357 12  5 f   -     -     -          751    0    0 
swift     826852444 11  3 f   -     -     -          751    0    0 
swift     826852504 11  2 Br  b     b     b          751   70    0 Ad 9d
swift     826852579 12  1 Bcc kr    kc    kf         681   60    0 
swift     826852759 12 12 c   b     r     b          621   90  365 Th Jc
swift     826852912 12 12 f   -     -     -          896    0    0 
swift     826853053 10  9 cc  kf    -     -          896   20    0 
swift     826853200 10  8 c   f     -     -          876   10    0 
swift     826853299 12  7 c   bc    kc    kc         866   70    0 Ah 7h
swift     826853414 11  6 r   bc    kcc   kf         796  120    0 
swift     826853529 10  4 f   Q     -     -          676    0    0 
swift     826857713 10  2 Bc  kcc   kc    kc         676  100  425 6d Qd
swift     826857857  8  1 Bc  kf    -     -         1001   10    0 
swift     826857957  8  8 f   -     -     -          991    0    0 
swift     826858113 10  8 f   -     -     -          991    0    0 
swift     826858231 10  7 f   -     -     -          991    0    0 
swift     826858341 11  7 f   -     -     -          991    0    0 
swift     826858444 10  5 r   r     cc    f          991  100    0 
swift     826858666 10  4 f   -     -     -          891    0    0 
swift     826858844 11  3 f   -     -     -          891    0    0 
swift     826858916 11  2 Bk  r     kr    f          891   70    0 
swift     826859027 12  1 Bcc kcf   -     -          821   50    0 
swift     826859193 12 12 c   rc    c     r          771  110  440 Js Ah
swift     826859323 11 10 f   -     -     -         1101    0    0 
swift     826859438  9  8 f   -     -     -         1101    0    0 
swift     826859529 10  7 f   -     -     -         1101    0    0 
swift     826859614 10  6 fQ  -     -     -         1101    0    0 
swift     826866749 11 10 c   c     b     k         1101   50    0 Jc Qs
swift     826866834 11  9 c   c     c     c         1051   70    0 Qs Ks
swift     826866883 11  8 f   -     -     -          981    0    0 
swift     826866965 11  7 c   bc    k     k          981   30  125 9c 8c
swift     826867051 12  6 cc  fQ    -     -         1076   20    0 
swift     826950039 12  2 Bk  kf    -     -         1056   10    0 
swift     826950135 12  1 Bcf -     -     -         1046   10    0 
swift     826950247 12 12 c   rc    c     k         1036  100  440 Th Td
swift     826950356 12 11 f   Q     -     -         1376    0    0 
swift     826952350 11  4 f   -     -     -         1376    0    0 
swift     826952501 11  3 r   kc    k     k         1376   40  118 Qs As
swift     826952691 11  2 Bc  kf    -     -         1454   20    0 
swift     826952791 11  1 Bc  kf    -     -         1434   10    0 
swift     826952901 10 10 c   c     c     f         1424   70    0 
swift     826953019 10  9 f   -     -     -         1354    0    0 
swift     826953077 10  8 cc  cc    f     -         1354   80    0 
swift     826953339 11  7 c   c     f     -         1274   20    0 
swift     826953663 10  7 KQ  -     -     -         1254    0    0 
swift     826986218  6  2 Br  b     bc    krrrrc    1254  250  540 Qd Qs
swift     826986330  6  1 Bc  kf    -     -         1544   10    0 
swift     826986369  5  5 f   -     -     -         1534    0    0 
swift     826986402  5  4 f   -     -     -         1534    0    0 
swift     826986427  4  3 c   kf    -     -         1534   10    0 
swift     826986453  4  2 Bk  r     k     k         1524   30    0 6c Qs
swift     826986486  4  1 Bf  -     -     -         1494    5    0 
swift     826986512  4  4 c   c     r     b         1489   80  170 Kd Td
swift     826986554  4  3 r   kf    -     -         1579   20    0 
swift     826986590  5  2 Bk  rc    c     c         1559   80    0 3c Qc
swift     826986627  5  1 Bc  k     b     b         1479   50  160 Ad 3s
swift     826986684  5  5 f   -     -     -         1589    0    0 
swift     826986725  5  4 cc  bc    k     c         1589   60    0 Kh 4d
swift     826986780  6  3 r   -     -     -         1529   20   35 
swift     826986797  6  2 Br  b     k     k         1544   30    0 9d 9h
swift     826986845  6  1 Bf  -     -     -         1514    5    0 
swift     826986937  6  6 f   -     -     -         1509    0    0 
swift     826986973  6  5 f   -     -     -         1509    0    0 
swift     826986988  6  4 c   cc    k     f         1509   30    0 
swift     826987050  6  3 c   b     -     -         1479   20   40 
swift     826987079  6  2 Bk  f     -     -         1499   10    0 
swift     826987117  6  1 Bccc bc    kf    Q         1489   60    0 
swift     826996204  7  4 c   f     -     -         1429   10    0 
swift     826996254  7  3 cc  kc    k     k         1419   30    0 6c 3c
swift     826996316  7  2 Bc  kc    k     kf        1389   30    0 
swift     826996401  9  1 Bc  kc    b     bc        1359   80    0 4s 8s
swift     826996493  9  9 c   f     -     -         1279   20    0 
swift     826996582  9  8 f   -     -     -         1259    0    0 
swift     826996657  9  7 c   c     f     -         1259   20    0 
swift     826996719  9  6 f   -     -     -         1239    0    0 
swift     826996821  9  5 c   kf    -     -         1239   10    0 
swift     826996933 11  4 f   -     -     -         1229    0    0 
swift     826997044  8  3 cc  kf    -     -         1229   20    0 
swift     826997106  9  2 Bk  kf    -     -         1209   10    0 
swift     826997209  9  1 Bc  b     k     k         1199   20    0 3s 4c
swift     826997272  9  9 f   -     -     -         1179    0    0 
swift     826997396  7  6 f   -     -     -         1179    0    0 
swift     826997467  8  6 f   -     -     -         1179    0    0 
swift     826997573  8  5 f   -     -     -         1179    0    0 
swift     826997654  9  5 r   b     b     b         1179   70  165 Qc Qh
swift     826997752  9  4 f   -     -     -         1274    0    0 
swift     826997879 10  4 c   f     -     -         1274   10    0 
swift     826997983  8  2 Bk  br    b     b         1264   80    0 2s Tc
swift     826998081  6  1 Bc  kf    -     -         1184   10    0 
swift     826998144  5  5 r   b     k     f         1174   30    0 
swift     826998195  6  5 f   -     -     -         1144    0    0 
swift     826998319  6  4 c   kc    bc    kc        1144   80    0 Kh 3s
swift     826998386  6  3 cc  kcc   kc    kf        1064   80    0 
swift     826998479  6  2 Bk  kf    -     -          984   10    0 
swift     826998590  5  1 BfQ -     -     -          974    5    0 
swift     827011563  6  2 Bc  c     f     -          969   30    0 
swift     827011630  6  1 Bf  -     -     -          939    5    0 
swift     827011647  5  5 c   c     c     f          934   50    0 
swift     827011736  7  6 rc  c     c     c          884   90    0 9d 9h
swift     827011837  7  5 f   -     -     -          794    0    0 
swift     827011895  7  4 f   -     -     -          794    0    0 
swift     827012031  9  4 f   -     -     -          794    0    0 
swift     827012138  7  2 Bf  -     -     -          794   10    0 
swift     827012180  7  1 Bf  -     -     -          784    5    0 
swift     827012243  8  8 f   -     -     -          779    0    0 
swift     827012415  8  8 c   rc    c     rrc        779  180  465 Kc 8d
swift     827012584  8  7 f   -     -     -         1064    0    0 
swift     827012815  7  5 c   cc    rc    rr        1064  220  685 9d Ac
swift     827012969  8  4 c   rc    c     c         1529   90  230 Kd 6d
swift     827013061  8  2 rc  f     -     -         1669   30    0 
swift     827013217  6  2 Bk  k     bc    b         1639   70  145 3s Ah
swift     827013268  3  1 BfQ -     -     -         1714    5    0 
swift     827021697  9  3 c   kf    -     -         1709   10    0 
swift     827021784  9  2 Bk  b     b     kc        1699   60    0 7d 2c
swift     827021863 10  1 Bc  kc    kf    -         1639   30    0 
swift     827021981 10 10 f   -     -     -         1609    0    0 
swift     827022053  9  8 f   -     -     -         1609    0    0 
swift     827022141  9  8 f   -     -     -         1609    0    0 
swift     827022206  9  7 c   c     c     bc        1609   80    0 Ah 5h
swift     827022367  7  5 cc  rf    -     -         1529   40    0 
swift     827022418  7  3 cc  br    br    b         1489  130  305 
swift     827022463  7  2 Bk  kf    -     -         1664   10    0 
swift     827022517  8  1 Bf  -     -     -         1654    5    0 
swift     827022549  7  7 f   -     -     -         1649    0    0 
swift     827022602  7  6 cc  k     Q     -         1649   20    0 
swift     827039607  9  1 Bc  bc    kf    -         1629   40    0 
swift     827039658  9  1 Bc  k     b     b         1589   60  130 4c Tc
swift     827039692  9  9 f   -     -     -         1659    0    0 
swift     827039746  9  8 c   f     -     -         1659   10    0 
swift     827039816 11  9 f   -     -     -         1649    0    0 
swift     827039911 10  7 c   f     -     -         1649   20    0 
swift     827039970  9  5 r   bc    kc    kc        1629   80    0 9d 9h
swift     827040028  8  3 c   f     -     -         1549   10    0 
swift     827040067  8  2 Br  b     b     b         1539   70  160 Th Ks
swift     827040132  8  1 Bc  k     k     k         1629   10    0 6s Js
swift     827040193  7  7 f   -     -     -         1619    0    0 
swift     827040264  6  5 f   -     -     -         1619    0    0 
swift     827040315  4  3 cc  c     r     b         1619   90    0 5d 3d
swift     827040362  4  2 Bc  k     k     b         1529   40   85 
swift     827040405  4  1 Br  brc   kc    k         1574   80  210 Ad 8d
swift     827040462  5  4 c   c     b     b         1704   60    0 3h 6d
swift     827040526  5  3 r   k     f     -         1644   20    0 
swift     827040567  5  2 Bk  kf    -     -         1624   10    0 
swift     827040591  5  1 Bf  -     -     -         1614    5    0 
swift     827040658  6  6 rc  c     c     c         1609   80    0 Qh Qc
swift     827040724  6  5 r   r     bc    rc        1529  140    0 Td Ah
swift     827040814  6  4 c   kc    k     kr        1389   60  200 9d 2d
swift     827040960  6  3 f   -     -     -         1529    0    0 
swift     827041035  6  2 Bk  kf    -     -         1529   10    0 
swift     827041079  7  1 Bcc br    b     b         1519   90  160 
swift     827041155  7  7 fQ  -     -     -         1589    0    0 
swift     827274931 10  2 Br  b     kr    b         1589  100  345 
swift     827275032 12  1 Bcc k     kf    -         1834   20    0 
swift     827275120  9  9 c   f     -     -         1814   20    0 
swift     827275177  9  8 c   c     c     k         1794   40  140 Kc Kh
swift     827275276  9  7 fQ  -     -     -         1894    0    0 
swift     827368265  9  5 c   r     k     b         1894   50   85 As 9h
swift     827368350  9  3 f   -     -     -         1929    0    0 
swift     827368452  8  2 Bk  kf    -     -         1929   10    0 
swift     827368567  8  1 Bf  -     -     -         1919    5    0 
swift     827368687  7  7 cc  f     -     -         1914   20    0 
swift     827368790 10  8 f   -     -     -         1894    0    0 
swift     827368866 11  7 f   -     -     -         1894    0    0 
swift     827368987 12  6 c   bc    bc    k         1894   70    0 9h 8d
swift     827369111 11  4 f   -     -     -         1824    0    0 
swift     827369245 11  2 Bc  kf    -     -         1824   20    0 
swift     827369370 10  1 BQ  -     -     -         1804    5    0 
swift     827373534  6  2 Bk  k     b     f         1799   30    0 
swift     827373635  6  1 Bc  kc    bc    kc        1769   80  200 Th Qs
swift     827373718  6  6 f   -     -     -         1889    0    0 
swift     827373797  7  5 f   -     -     -         1889    0    0 
swift     827373852  7  4 c   k     kc    bc        1889   70    0 5h Qh
swift     827373958  7  3 f   -     -     -         1819    0    0 
swift     827374041  7  2 Bk  kf    -     -         1819   10    0 
swift     827374146  8  1 Br  b     k     k         1809   30    0 As Th
swift     827374210  7  7 c   f     -     -         1779   10    0 
swift     827374289  8  7 f   -     -     -         1769    0    0 
swift     827374386  7  5 c   b     k     f         1769   20    0 
swift     827374484  7  4 c   k     f     -         1749   10    0 
swift     827374550  7  3 c   r     k     k         1739   30    0 Td Js
swift     827374613  8  2 Br  k     cr    kc        1709  100    0 Qd Ad
swift     827374739  8  1 Br  bc    kc    k         1609   60  190 Ad Td
swift     827374812  8  8 f   -     -     -         1739    0    0 
swift     827374901  9  8 f   -     -     -         1739    0    0 
swift     827375004 10  8 c   c     f     -         1739   20    0 
swift     827375095 12  9 cc  k     f     -         1719   20    0 
swift     827375226 10  8 f   -     -     -         1699    0    0 
swift     827375387  9  6 f   -     -     -         1699    0    0 
swift     827375458  9  5 f   -     -     -         1699    0    0 
swift     827375576 10  4 c   kf    -     -         1699   10    0 
swift     827375656 10  3 fQ  -     -     -         1689    0    0 
swift     827375770 10 10 f   -     -     -         1689    0    0 
swift     827375873 10  9 cc  f     -     -         1689   40    0 
swift     827376048 11  9 c   c     f     -         1649   20    0 
swift     827376216 11  9 cc  kf    -     -         1629   20    0 
swift     827376395 10  7 f   -     -     -         1609    0    0 
swift     827376548 10  6 f   -     -     -         1609    0    0 
swift     827376669 11  6 cc  kf    -     -         1609   20    0 
swift     827376762 10  4 f   -     -     -         1589    0    0 
swift     827376825 11  3 c   kf    -     -         1589   10    0 
swift     827376936 11  2 Bk  b     b     b         1579   60  130 
swift     827376985 11  1 Bc  k     b     kc        1649   50    0 3s 8s
swift     827377061 11 11 c   c     k     b         1599   40  130 
swift     827377187 10  9 f   -     -     -         1689    0    0 
swift     827377295  9  8 cc  cc    bf    -         1689   60    0 
swift     827377453  7  4 Q   -     -     -         1629    0    0 
swift     827448141  7  7 f   -     -     -         1629    0    0 
swift     827448193  7  6 f   -     -     -         1629    0    0 
swift     827448307 10  7 c   k     c     f         1629   30    0 
swift     827448389 10  6 f   -     -     -         1599    0    0 
swift     827448459 11  6 c   r     bc    c         1599   90    0 3c 5c
swift     827448574 12  3 Q   -     -     -         1509    0    0 
swift     827451250 12  8 c   k     c     c         1509   50  150 8s Th
swift     827451317 12  7 c   f     -     -         1609   20    0 
swift     827451391 10  4 f   -     -     -         1589    0    0 
swift     827451448 11  3 f   -     -     -         1589    0    0 
swift     827451485 11  2 Bc  kf    Q     -         1589   20    0 
swift     827460327 12  7 c   b     kc    kf        1569   40    0 
swift     827460438 12  6 cc  c     c     k         1529   60    0 9c Th
swift     827460561 12  5 f   -     -     -         1469    0    0 
swift     827460656 12  4 f   -     -     -         1469    0    0 
swift     827460855 11  2 Br  b     b     b         1469   70  180 Td Ad
swift     827460932 11  1 Bf  -     -     -         1579    5    0 
swift     827461035 12 12 f   -     -     -         1574    0    0 
swift     827461095 12 11 f   -     -     -         1574    0    0 
swift     827461200 12 10 f   -     -     -         1574    0    0 
swift     827461294 12  9 c   c     c     f         1574   50    0 
swift     827461419 12  8 cc  k     f     -         1524   20    0 
swift     827461478 12  7 f   -     -     -         1504    0    0 
swift     827461673 11  6 c   bc    k     kc        1504   50    0 Ac Jh
swift     827461765 11  4 fQ  -     -     -         1454    0    0 
swift     827464362  9  3 f   -     -     -         1454    0    0 
swift     827464473 10  3 f   -     -     -         1454    0    0 
swift     827464576 10  2 Bk  kcc   kc    kc        1454   80    0 3c Kc
swift     827464668 10  1 Bf  -     -     -         1374    5    0 
swift     827464849  9  9 f   -     -     -         1369    0    0 
swift     827464950  9  4 Q   -     -     -         1369    0    0 
swift     827555252 12 10 f   -     -     -         1369    0    0 
swift     827555309 12  9 f   -     -     -         1369    0    0 
swift     827555390 12  8 c   kf    -     -         1369   10    0 
swift     827555445 11  6 c   k     c     f         1359   40    0 
swift     827555524 10  5 r   b     k     c         1319   50  125 9d 9c
swift     827555571 10  4 f   -     -     -         1394    0    0 
swift     827555625 10  3 f   -     -     -         1394    0    0 
swift     827555717 12  2 Br  b     kc    kc        1394   70    0 Jd Kd
swift     827555809 12  1 Bf  -     -     -         1324    5    0 
swift     827555844 12 12 r   r     b     b         1319   80  175 
swift     827555889 11 10 f   -     -     -         1414    0    0 
swift     827555913 11  9 c   f     -     -         1414   10    0 
swift     827555968 12  9 f   -     -     -         1404    0    0 
swift     827556015 12  8 f   -     -     -         1404    0    0 
swift     827556077 11  6 cc  f     -     -         1404   20    0 
swift     827556145 12  5 cc  br    bc    kc        1384  110    0 4s 4d
swift     827556245 12  4 f   -     -     -         1274    0    0 
swift     827556316 12  3 f   -     -     -         1274    0    0 
swift     827556377 12  2 Bk  kc    kc    kf        1274   40    0 
swift     827556435 12  1 Bcc kf    -     -         1234   20    0 
swift     827556535  9  9 c   f     -     -         1214   10    0 
swift     827556623 11 10 fQ  -     -     -         1204    0    0 
swift     827558579 12  9 c   r     b     b         1204   70  195 
swift     827558696 10  7 f   -     -     -         1329    0    0 
swift     827558820  8  5 c   k     k     k         1329   20    0 2c 5c
swift     827558887  7  4 f   -     -     -         1309    0    0 
swift     827558917  7  3 c   kf    -     -         1309   10    0 
swift     827559039  7  1 Bc  k     b     bf        1299   60    0 
swift     827559112  7  1 Brc kc    k     kf        1239   50    0 
swift     827559189  6  6 f   -     -     -         1189    0    0 
swift     827559267  6  5 f   -     -     -         1189    0    0 
swift     827559281  6  4 f   -     -     -         1189    0    0 
swift     827559324  6  3 f   -     -     -         1189    0    0 
swift     827559333  6  2 Bc  kf    -     -         1189   20    0 
swift     827559371  6  1 Bc  kf    -     -         1169   10    0 
swift     827559412  7  7 f   -     -     -         1159    0    0 
swift     827559465  7  6 c   f     -     -         1159   10    0 
swift     827559533  7  5 c   c     f     -         1149   20    0 
swift     827559570  6  3 r   b     -     -         1129   30   65 
swift     827559605  6  2 Bk  kf    -     -         1164   10    0 
swift     827559658  6  1 Bf  -     -     -         1154    5    0 
swift     827559701  4  4 c   c     c     f         1149   40    0 
swift     827559740  3  3 cc  k     f     -         1109   20    0 
swift     827559768  3  2 Bf  -     -     -         1089   10    0 
swift     827559775  3  1 Bc  bc    bc    kc        1079  100  210 5c Kd
swift     827559799  3  3 fQ  -     -     -         1189    0    0 
swift     827562367  4  3 r   b     -     -         1189   30   65 
swift     827562380  4  2 B   -     -     -         1224   10   15 
swift     827562389  4  1 Bc  bc    kc    kf        1229   80    0 
swift     827562447  4  4 f   -     -     -         1149    0    0 
swift     827562472  4  3 cc  kf    -     -         1149   20    0 
swift     827562498  4  2 Br  c     k     f         1129   30    0 
swift     827562541  4  1 Bcc kc    b     -         1099   50   80 
swift     827562571  4  4 f   -     Q     -         1129    0    0 
swift     827622382  5  2 Bk  b     -     -         1129   20   30 
swift     827622402  4  1 Bf  -     -     -         1139    5    0 
swift     827622415  4  4 f   -     -     -         1134    0    0 
swift     827622445  5  3 cc  c     c     c         1134   70    0 Td As
swift     827622500  4  1 Bk  b     b     -         1064   40   70 
swift     827622531  2  1 Bf  -     -     -         1094    5    0 
swift     827622538  2  2 BQ  -     -     -         1089   10    0 
swift     828065910  4  4 f   -     -     -         1079    0    0 
swift     828065936  4  3 cc  k     f     -         1079   20    0 
swift     828065993  5  2 Bk  k     b     k         1059   30    0 Ts 8d
swift     828066032  6  1 Bf  -     -     -         1029    5    0 
swift     828066069  6  6 c   k     f     -         1024   20    0 
swift     828066133  6  5 c   c     c     k         1004   50    0 Kd 2d
swift     828066183  6  4 r   c     b     rc         954  110  112 Js As
swift     828066228  6  3 rc  k     k     kc         956   50    0 Js Qs
swift     828066268  6  2 Bc  k     k     b          906   40   85 8d 9c
swift     828066311  6  1 Bf  -     -     -          951    5    0 
swift     828066415  6  6 c   b     -     -          946   20   40 
swift     828066450  6  5 f   -     -     -          966    0    0 
swift     828066508  7  5 f   -     -     -          966    0    0 
swift     828066564  8  5 f   -     -     -          966    0    0 
swift     828066637  8  4 cc  k     c     c          966   60  165 Kc 8c
swift     828066709  8  4 f   -     -     -         1071    0    0 
swift     828066749  9  3 f   -     -     -         1071    0    0 
swift     828066805 10  3 f   -     -     -         1071    0    0 
swift     828066876 10  2 Bf  -     -     -         1071   10    0 
swift     828066933 11  1 Bf  -     -     -         1061    5    0 
swift     828067040 12 12 f   -     -     -         1056    0    0 
swift     828067164 11 10 f   -     -     -         1056    0    0 
swift     828067232 12  9 f   -     -     -         1056    0    0 
swift     828067320 10  8 c   r     k     kf        1056   40    0 
swift     828067405  9  6 f   -     -     -         1016    0    0 
swift     828067436  9  5 cc  kf    -     -         1016   20    0 
swift     828067519 11  4 c   kc    kc    krc        996  120  385 Jh Jd
swift     828067630 11  3 c   kc    kc    kc        1261   60    0 2h As
swift     828067787 11  2 Bc  kf    Q     -         1201   20    0 
swift     828155115 11  6 f   -     -     -         1181    0    0 
swift     828155275  8  2 r   b     -     -         1181   30   60 
swift     828155327  8  2 Bc  kc    kr    k         1211   70  145 4s 7s
swift     828155397  9  1 Bf  -     -     -         1286    5    0 
swift     828155534  8  8 f   -     -     -         1281    0    0 
swift     828155617  9  9 cc  k     bc    c         1281   80    0 Td Ad
swift     828155689 10  8 f   -     -     -         1201    0    0 
swift     828155808  8  6 c   k     kc    kr        1201   70  185 2h Ad
swift     828155900  8  5 f   -     -     -         1316    0    0 
swift     828155978  8  4 f   -     -     -         1316    0    0 
swift     828156090  9  3 c   k     k     c         1316   30    0 5c Kc
swift     828156237  8  2 Bk  kf    -     -         1286   10    0 
swift     828156296  8  1 Bc  kc    kc    kc        1276   70  180 Th Kh
swift     828156370  8  8 fQ  -     -     -         1386    0    0 
swift     828157881  8  6 c   kf    -     -         1386   10    0 
swift     828157977 10  5 f   -     -     -         1376    0    0 
swift     828158049  9  4 cc  bc    bc    kc        1376  100    0 Th Qs
swift     828158143  9  3 c   rc    kr    b         1276  100  230 
swift     828158211  9  2 Bc  kf    -     -         1406   20    0 
swift     828158337 10  1 Bf  -     -     -         1386    5    0 
swift     828158416 11 11 f   -     -     -         1381    0    0 
swift     828158512 11 10 r   b     k     k         1381   40   60 As Kc
swift     828158639 10  9 f   -     -     -         1401    0    0 
swift     828158690 10  8 cc  c     c     kf        1401   50    0 
swift     828158792 10  7 f   -     -     -         1351    0    0 
swift     828158827  8  5 cc  f     -     -         1351   20    0 
swift     828158905  9  5 c   bc    k     kf        1331   30    0 
swift     828159035  8  3 f   -     -     -         1301    0    0 
swift     828159131  8  3 fQQQ -     -     -         1301    0    0 
swift     828163297  8  2 Bf  -     -     -         1301   10    0 
swift     828163390  8  1 Bf  -     -     -         1291    5    0 
swift     828163485  8  8 c   f     -     -         1286   10    0 
swift     828163552 10  8 f   -     -     -         1276    0    0 
swift     828163639 11  8 f   -     -     -         1276    0    0 
swift     828163743 11  7 f   -     -     -         1276    0    0 
swift     828163893 11  6 f   -     -     -         1276    0    0 
swift     828164005 11  5 c   f     -     -         1276   10    0 
swift     828164119 12  4 f   -     -     -         1266    0    0 
swift     828164271 12  3 f   -     -     -         1266    0    0 
swift     828164379  9  2 Br  k     kc    krr       1266  120  440 As Ah
swift     828164524  9  1 Bc  b     k     k         1586   20    0 8h Jd
swift     828164615 10 10 f   -     -     -         1566    0    0 
swift     828164744 10  9 cc  f     -     -         1566   20    0 
swift     828164854 11  8 f   -     -     -         1546    0    0 
swift     828164960 11  7 f   -     -     -         1546    0    0 
swift     828165119 11  6 f   -     -     -         1546    0    0 
swift     828165212 12  5 f   -     -     -         1546    0    0 
swift     828165401 11  4 f   -     -     -         1546    0    0 
swift     828165667 11  3 f   -     -     -         1546    0    0 
swift     828165883 11  2 Bk  kf    -     -         1546   10    0 
swift     828166016 11  1 Bc  k     k     kf        1536   10    0 
swift     828166189  9  9 c   fQ    -     -         1526   10    0 
swift     828207309  6  5 c   k     b     bc        1516   70  100 Ah 4s
swift     828207374  6  4 f   -     -     -         1546    0    0 
swift     828207402  6  3 f   -     -     -         1546    0    0 
swift     828207447  5  2 Bc  c     f     -         1546   30    0 
swift     828207494  5  1 Bc  kc    kKQ   -         1516   20    0 
swift     828208101  5  4 f   -     -     -         1496    0    0 
swift     828208151  5  4 f   -     -     -         1496    0    0 
swift     828208190  4  2 Bf  -     -     -         1496   10    0 
swift     828208236  4  1 Br  -     -     -         1486   20   30 
swift     828208250  4  4 f   -     -     -         1496    0    0 
swift     828208282  4  3 c   b     b     b         1496   60  120 
swift     828208336  5  2 Bf  -     -     -         1556   10    0 
swift     828208377  5  1 Bc  kf    -     -         1546   10    0 
swift     828208458  5  5 f   -     -     -         1536    0    0 
swift     828208495  5  4 f   -     -     -         1536    0    0 
swift     828208540  5  3 r   b     f     -         1536   30    0 
swift     828208602  5  2 Bk  k     b     -         1506   30   50 
swift     828208645  5  1 Bcf -     -     -         1526   10    0 
swift     828208698  5  5 f   -     -     -         1516    0    0 
swift     828208763  5  4 cc  kf    -     -         1516   20    0 
swift     828208826  5  3 f   -     -     -         1496    0    0 
swift     828208874  5  2 Bk  kf    -     -         1496   10    0 
swift     828208904  5  1 Bc  k     b     k         1486   30   70 Ah 5c
swift     828208954  6  6 f   -     -     -         1526    0    0 
swift     828209009  7  6 c   r     b     k         1526   50    0 7s 8h
swift     828209068  7  5 c   f     -     -         1476   20    0 
swift     828209108  7  4 c   f     -     -         1456   10    0 
swift     828209170  7  3 f   -     -     -         1446    0    0 
swift     828209211  6  2 Bf  -     -     -         1446   10    0 
swift     828209268  7  1 Br  bc    br    brrc      1436  220  250 Qs Kc
swift     828209410  6  6 c   k     f     -         1466   10    0 
swift     828209489  7  6 f   -     -     -         1456    0    0 
swift     828209555  6  4 f   -     -     -         1456    0    0 
swift     828209595  6  3 c   kf    -     -         1456   10    0 
swift     828209665  6  2 Bk  bf    -     -         1446   20    0 
swift     828209725  6  1 Bf  -     -     -         1426    5    0 
swift     828209779  6  6 f   -     -     -         1421    0    0 
swift     828209831  7  6 c   k     b     b         1421   50  100 
swift     828209916  7  6 cc  b     k     b         1471   50  160 6h Ac
swift     828210042  7  5 c   k     k     k         1581   10    0 6s 7s
swift     828210106  7  4 r   c     f     Q         1571   30    0 
swift     828243888  6  6 r   c     c     k         1541   50    0 4c Ah
swift     828243966  3  3 f   -     -     -         1491    0    0 
swift     828243973  3  2 Bk  k     k     f         1491   10    0 
swift     828243996  3  1 Bc  k     kf    -         1481   10    0 
swift     828244086  2  2 f   -     -     -         1471    0    0 
swift     828244093  2  2 BQ  -     -     -         1471   10    0 
swift     828245298  6  5 f   -     -     -         1461    0    0 
swift     828245365  6  4 c   bc    kc    kf        1461   50    0 
swift     828245441  6  3 f   -     -     -         1411    0    0 
swift     828245497  6  2 Bk  k     kf    -         1411   10    0 
swift     828245546  6  1 Bf  -     -     -         1401    5    0 
swift     828245604  7  6 r   b     br    b         1396  110  240 Tc Ts
swift     828245663  7  4 cc  c     b     c         1526   70    0 6c Kc
swift     828245745  7  4 r   b     b     b         1456   70  145 Qd As
swift     828245865  7  3 r   bf    -     -         1531   30    0 
swift     828245924  7  2 Bk  k     kf    -         1501   10    0 
swift     828245992  7  1 Bc  bc    b     kc        1491   70    0 4h Qc
swift     828246084  8  7 f   -     -     -         1421    0    0 
swift     828246203  8  6 c   f     -     -         1421   20    0 
swift     828246305  9  5 r   kf    -     -         1401   20    0 
swift     828246412  7  2 f   -     -     -         1381    0    0 
swift     828246457  7  1 Brc b     b     kc        1381   80  220 Tc Kc
swift     828246525  7  1 Bc  b     k     b         1521   40   90 Th 7h
swift     828246582  6  5 Q   -     -     -         1571    0    0 
swift     828294771 10  7 c   k     f     -         1571   10    0 
swift     828294859 10  5 r   b     b     b         1561   70  310 Kd Kh
swift     828295000 11  5 f   -     -     -         1801    0    0 
swift     828295089 11  4 f   -     -     -         1801    0    0 
swift     828295172  9  2 Bk  kf    -     -         1801   10    0 
swift     828295280  6  1 Bf  -     -     -         1791    5    0 
swift     828295338  6  6 f   -     -     -         1786    0    0 
swift     828295385  7  6 f   -     -     -         1786    0    0 
swift     828295403  5  4 r   k     r     b         1786   80  175 6c 6d
swift     828295446  6  4 c   f     -     -         1881   10    0 
swift     828295495  6  3 r   b     k     b         1871   50  140 Ah 8h
swift     828295552  6  2 Bk  kf    -     -         1961   10    0 
swift     828295619  5  1 Bc  kc    kf    -         1951   30    0 
swift     828295684  6  6 f   -     -     -         1921    0    0 
swift     828295737  7  6 c   k     k     b         1921   40  125 Ac 4c
swift     828295794  7  5 f   -     -     -         2006    0    0 
swift     828295862  9  5 c   c     b     b         2006   70  195 Ks 9s
swift     828295927  8  4 r   bc    r     c         2131  100  285 Qs Qc
swift     828295994 11  3 f   -     Q     -         2316    0    0 
swift     828307625  9  8 f   -     -     -         2316    0    0 
swift     828307758  9  7 f   -     -     -         2316    0    0 
swift     828307817  8  5 f   -     -     -         2316    0    0 
swift     828307894  9  4 f   -     -     -         2316    0    0 
swift     828307953 10  3 f   -     -     -         2316    0    0 
swift     828308045 10  2 Bc  kc    kf    -         2316   30    0 
swift     828308132 10  1 Bc  kf    -     -         2286   10    0 
swift     828308280 11 11 fQ  -     -     -         2276    0    0 
