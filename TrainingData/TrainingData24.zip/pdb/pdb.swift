swift     860303412  5  2 Bf  -     -     -         4430   10    0 
swift     860303445  5  1 Bf  -     -     -         4420    5    0 
swift     860303457  4  4 f   -     -     -         4415    0    0 
swift     860303511  4  3 Q   -     -     -         4415    0    0 
swift     860904384  6  3 f   -     -     -         4415    0    0 
swift     860904427  6  2 Bk  b     k     b         4415   40   70 
swift     860904458  6  1 Bc  kc    kf    -         4445   20    0 
swift     860904543  7  5 f   -     -     -         4425    0    0 
swift     860904619  6  4 cc  k     b     -         4425   40  105 
swift     860904706  7  3 cc  kf    -     -         4490   20    0 
swift     860904725  7  2 Bcc kc    kr    b         4470  110  295 9c Qh
swift     860904797  7  1 Bcc kf    -     -         4655   30    0 
swift     860904858  7  7 cc  k     f     -         4625   30    0 
swift     860904903  7  6 Q   -     -     -         4595    0    0 
swift     860905056  8  3 cc  kc    kc    kc        4595   90    0 7s 8h
swift     860905106  8  2 Bf  -     -     -         4505   10    0 
swift     860905149  8  1 Bc  kc    kf    -         4495   30    0 
swift     860905211  8  8 c   c     c     f         4465   50    0 
swift     860905255  8  7 cc  brc   kc    kc        4415  120    0 8c 8d
swift     860905315  8  6 f   -     -     -         4295    0    0 
swift     860905365  9  5 f   -     -     -         4295    0    0 
swift     860905426  9  4 Q   -     -     -         4295    0    0 
swift     862115243  5  3 f   -     -     -         3975    0    0 
swift     862115303  4  2 Bk  k     k     k         3975   10   13 9d 6c
swift     862115327  4  1 Bc  b     k     kf        3978   20    0 
swift     862115378  5  4 f   -     -     -         3958    0    0 
swift     862115414  6  3 c   k     b     kf        3958   30    0 
swift     862115510  7  2 Bc  k     k     k         3928   20    0 4h Qc
swift     862115551  8  1 Bf  -     -     -         3908    5    0 
swift     862115637  8  8 f   -     -     -         3903    0    0 
swift     862115699  8  7 cc  c     f     -         3903   40    0 
swift     862115784  8  6 f   -     -     -         3863    0    0 
swift     862115906  8  5 c   f     -     -         3863   10    0 
swift     862115950  7  4 f   -     -     -         3853    0    0 
swift     862116014  8  3 f   -     -     -         3853    0    0 
swift     862116090  9  2 Br  b     b     k         3853   50    0 Ad Tc
swift     862116179  8  1 Bc  k     krc   kc        3803  100    0 Kd Jh
swift     862116272  9  9 c   f     -     -         3703   10    0 
swift     862116321  9  8 c   cf    -     -         3693   40    0 
swift     862116436  9  7 f   -     -     -         3653    0    0 
swift     862116500 10  7 cc  cc    c     k         3653   70    0 4h 5d
swift     862116558 11  7 ccc f     -     -         3583   40    0 
swift     862116663 11  6 c   kc    k     kc        3543   40    0 5s As
swift     862116783 12  6 fQ  -     -     -         3503    0    0 
