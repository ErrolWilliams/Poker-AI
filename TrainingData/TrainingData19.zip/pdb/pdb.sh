sh        849367237  4  3 rc  kc    k     b         1000   60  170 5h 4h
sh        849367274  4  2 Bk  f     -     -         1110   10    0 
sh        849367288  4  1 Br  k     b     k         1100   40    0 Js Qd
sh        849367316  4  4 rc  c     c     k         1060   60  130 Kh Td
sh        849367341  4  3 cc  rc    c     c         1130   90    0 Jh Qs
sh        849367375  4  2 Bf  -     -     -         1040   10    0 
sh        849367388  4  1 Br  bc    kc    b         1030   80    0 Qd Kd
sh        849367425  4  4 f   -     -     -          950    0    0 
sh        849367452  4  3 c   k     k     k          950   10   30 9s 3s
sh        849367483  5  2 Bk  kf    Q     -          970   10    0 
