swift     831175435  5  5 r   c     c     c          720   70    0 Ad 5s
swift     831175483  6  5 c   c     r     b          650   90  185 
swift     831175526  6  4 f   -     -     -          745    0    0 
swift     831175629  5  3 f   -     -     -          745    0    0 
swift     831175667  6  2 Bc  kf    -     -          745   20    0 
swift     831175749  6  1 Bc  b     b     k          725   40  100 2c As
swift     831175796  6  6 f   -     -     -          785    0    0 
swift     831175846  6  5 f   -     -     -          785    0    0 
swift     831175906  6  4 f   -     -     -          785    0    0 
swift     831175974  7  3 f   -     -     -          785    0    0 
swift     831176050  7  2 Bc  cc    kc    kc         785   80  300 6h As
swift     831176162  7  1 Bc  kf    -     -         1005   10    0 
swift     831176231  7  7 cc  c     b     bc         995  100    0 Js 9h
swift     831176350  7  6 cc  f     -     -          895   20    0 
swift     831176429  7  5 f   -     -     -          875    0    0 
swift     831176475  7  4 f   -     -     -          875    0    0 
swift     831176519  8  3 cc  cc    c     c          875  100  345 Qs 9s
swift     831176599 10  2 Bk  k     c     r         1120   70  250 4d Ad
swift     831176710  9  1 Bc  kf    -     -         1300   10    0 
swift     831176858  9  9 c   bc    f     Q         1290   30    0 
swift     831178608 11 11 c   c     f     -         1260   20    0 
swift     831178751 10  9 f   -     -     -         1240    0    0 
swift     831178851 10  8 f   -     -     -         1240    0    0 
swift     831178976 11  8 c   f     -     -         1240   20    0 
swift     831179104 11  7 cc  fQ    -     -         1220   40    0 
swift     831185643  7  5 f   -     -     -         1055    0    0 
swift     831185695  7  3 f   -     -     -         1055    0    0 
swift     831185738  7  2 Bk  kfQ   -     -         1055   10    0 
swift     831272153  7  2 Bk  kc    kf    -         1045   20    0 
swift     831272200  6  1 Bc  kf    -     -         1025   20    0 
swift     831272268  6  6 f   -     -     -         1005    0    0 
swift     831272309  6  5 f   -     -     -         1005    0    0 
swift     831272363  6  4 f   -     -     -         1005    0    0 
swift     831272416  7  3 f   -     -     -         1005    0    0 
swift     831272517  8  2 Bf  -     -     -         1005   10    0 
swift     831272601  8  1 Br  b     bc    kc         995   90  210 Kc Ad
swift     831272653  8  8 f   -     -     -         1115    0    0 
swift     831272746  9  8 c   c     c     f         1115   40    0 
swift     831272819  8  6 c   kf    -     -         1075   10    0 
swift     831272855  8  5 f   -     -     -         1065    0    0 
swift     831272904  8  4 c   b     b     -         1065   40   75 
swift     831272951  8  3 f   -     -     -         1100    0    0 
swift     831273017  8  2 Br  bc    kf    -         1100   40    0 
swift     831273055  9  1 Bc  bc    kf    -         1060   30    0 
swift     831273132  9  9 f   -     -     -         1030    0    0 
swift     831273199 10  9 cc  f     -     -         1030   20    0 
swift     831273328 10  8 f   -     -     -         1010    0    0 
swift     831273412 11  8 f   -     -     -         1010    0    0 
swift     831273506 11  7 c   cc    kc    k         1010   50    0 8h Kh
swift     831273613  9  4 rc  f     -     -          960   30    0 
swift     831273751  8  3 f   -     -     -          930    0    0 
swift     831273832  9  2 Br  cc    b     c          930   80    0 9s Js
swift     831273957 10  1 Bf  -     -     -          850    5    0 
swift     831274044 10 10 f   -     -     -          845    0    0 
swift     831274117  9  8 cc  c     r     b          845  100    0 9d As
swift     831274196 10  8 c   rc    c     c          745   80    0 Jc 4c
swift     831274299 10  7 c   f     -     -          665   10    0 
swift     831274398 11  7 f   -     -     -          655    0    0 
swift     831274466 10  5 r   b     -     -          655   30   80 
swift     831274506 10  5 c   rr    bc    kc         705  110    0 Qh Ad
swift     831274577 11  4 r   kf    -     -          595   20    0 
swift     831274646 11  3 c   k     kf    -          575   10    0 
swift     831274713 11  2 Bk  bc    kc    kc         565   70  220 Tc Jh
swift     831274791 12  1 Bc  kf    -     -          715   10    0 
swift     831274886 12 12 c   k     r     b          705   70  225 
swift     831275066  8  7 c   cc    k     b          860   60  210 Td 9d
swift     831275154  8  6 f   -     -     -         1010    0    0 
swift     831275241  7  5 f   -     -     -         1010    0    0 
swift     831275297  6  3 f   -     -     -         1010    0    0 
swift     831275340  7  2 Bc  f     -     -         1010   30    0 
swift     831275401  7  1 Bf  -     -     -          980    5    0 
swift     831275461  7  7 c   f     -     -          975   10    0 
swift     831275525  7  6 ccc f     -     -          965   40    0 
swift     831275601  7  5 f   -     -     -          925    0    0 
swift     831275662  7  4 f   -     -     -          925    0    0 
swift     831275770  7  3 r   kc    k     k          925   30  135 Kd Ac
swift     831275825  6  2 Bc  kf    -     -         1030   20    0 
swift     831275914  5  1 Bc  kf    -     -         1010   10    0 
swift     831276026  4  4 c   c     f     -         1000   30    0 
swift     831276052  4  4 c   c     c     b          970   60  140 5s Qs
swift     831276094  4  3 r   br    k     b         1050   70  145 Kh 9h
swift     831276215  3  2 Bc  kf    -     -         1125   20    0 
swift     831276232  3  1 Br  bf    -     -         1105   30    0 
swift     831276249  3  3 f   -     -     -         1075    0    0 
swift     831276262  3  2 Bk  b     b     k         1075   40   80 5c Td
swift     831276295  3  1 Bc  b     b     k         1115   40   80 7h 9s
swift     831276324  3  3 f   -     -     -         1155    0    0 
swift     831276343  3  2 Bk  k     b     -         1155   30   40 
swift     831276378  3  1 Bc  kf    -     -         1165   10    0 
swift     831276394  3  3 cc  c     f     -         1155   40    0 
swift     831276429  3  2 Bc  kc    kr    k         1115   70  145 8s 7d
swift     831276457  3  1 Bc  kf    -     -         1190   10    0 
swift     831276474  3  3 f   -     -     -         1180    0    0 
swift     831276479  3  2 Bk  b     -     -         1180   20   30 
swift     831276495  3  1 Bc  b     -     -         1190   20   30 
swift     831276506  3  3 f   -     -     -         1200    0    0 
swift     831276519  3  2 Bf  -     -     -         1200   10    0 
swift     831276536  3  1 Br  b     bf    -         1190   50    0 
swift     831276564  3  3 f   -     -     -         1140    0    0 
swift     831276585  3  2 Brc b     k     b         1140   60  130 Ks Th
swift     831276609  3  1 Br  bc    kr    b         1210  100  180 
swift     831276636  3  3 c   k     k     f         1290   10    0 
swift     831276665  3  2 Bk  kf    -     -         1280   10    0 
swift     831276679  3  1 Bf  -     -     -         1270    5    0 
swift     831276695  3  3 f   -     -     -         1265    0    0 
swift     831276715  3  2 Bk  bc    kf    -         1265   30    0 
swift     831276738  3  1 Bcc kf    -     -         1235   20    0 
swift     831276793  3  3 f   -     -     -         1215    0    0 
swift     831276831  3  2 Bc  kc    kr    b         1215   90  185 Td Jd
swift     831276855  3  1 Bf  -     -     -         1310    5    0 
swift     831276867  3  3 f   -     -     -         1305    0    0 
swift     831276880  3  2 Br  b     b     -         1305   50   80 
swift     831276911  3  1 Bf  -     -     -         1335    5    0 
swift     831276931  3  3 cc  c     r     bc        1330  110  290 Qd Jc
swift     831276974  3  2 B   -     -     -         1510   10   15 
swift     831276984  3  1 Brc kc    kc    kc        1515   80    0 Tc Ah
swift     831277014  3  3 f   -     -     -         1435    0    0 
swift     831277027  3  2 B   -     -     -         1435   10   15 
swift     831277032  3  1 Bc  kf    -     -         1440   10    0 
swift     831277047  3  3 f   -     -     -         1430    0    0 
swift     831277062  3  2 Br  k     br    brc       1430  160  340 4d Kh
swift     831277102  3  1 Bc  k     b     kf        1610   30    0 
swift     831277133  3  3 c   b     b     b         1580   60  105 
swift     831277169  3  2 B   -     -     -         1625   10   15 
swift     831277176  3  1 Bc  kf    -     -         1630   10    0 
swift     831277192  3  3 f   -     -     -         1620    0    0 
swift     831277198  3  2 Bk  k     f     -         1620   10    0 
swift     831277214  3  1 Bc  b     bc    kc        1610   80    0 4h 3c
swift     831277243  3  3 cc  c     c     c         1530   70    0 6s Js
swift     831277268  3  2 Bk  b     -     -         1460   20   35 
swift     831277281  3  1 Bc  kf    -     -         1475   10    0 
swift     831277311  3  3 rc  c     f     -         1465   40    0 
swift     831277331  3  2 Br  b     b     b         1425   80    0 Qs Ks
swift     831277351  3  1 Bcc kf    -     -         1345   20    0 
swift     831277368  3  3 rc  f     -     -         1325   40    0 
swift     831277391  3  2 Bc  k     f     -         1285   20    0 
swift     831277417  3  1 Bc  bc    kr    b         1265   90  190 Kc 3d
swift     831277446  3  3 rc  c     f     -         1365   40    0 
swift     831277478  3  2 Br  bc    kf    -         1325   50    0 
swift     831277498  3  1 Br  -     -     -         1275   20   30 
swift     831277505  3  3 r   r     k     c         1285   70    0 Qc Qd
swift     831277532  3  2 Bc  kf    -     -         1215   20    0 
swift     831277566  3  1 Bc  bc    kc    kc        1195   70    0 Ks 7s
swift     831277592  4  3 f   Q     -     -         1125    0    0 
swift     831791752  9  2 Bk  kc    krr   bc        1125  140    0 7c 8d
swift     831791867  9  1 Bc  bc    kc    k          985   60    0 Jc 9h
swift     831791948  8  8 f   -     -     -          925    0    0 
swift     831792007  9  8 f   -     -     -          925    0    0 
swift     831792100  8  6 r   b     brc   r          925  150  415 Kc As
swift     831792184  9  5 f   -     -     -         1190    0    0 
swift     831792235  9  4 cc  kc    kc    kc        1190   80    0 Ts Qc
swift     831792321  9  3 c   kc    kc    kc        1110   60  160 5c Ac
swift     831792385 10  2 Bf  -     -     -         1210   10    0 
swift     831792478 10  1 Bc  kf    -     -         1200   10    0 
swift     831792525  9  9 r   b     b     b         1190   70  170 9s Ac
swift     831792566  9  8 f   -     -     -         1290    0    0 
swift     831792716  9  7 c   f     -     -         1290   10    0 
swift     831792774 10  7 c   k     f     -         1280   10    0 
swift     831792838 10  6 c   c     c     rr        1270  120  300 As 9s
swift     831792907 10  5 cc  f     -     -         1450   30    0 
swift     831792977  9  3 f   -     -     -         1420    0    0 
swift     831793077  9  2 Bk  kf    -     -         1420   10    0 
swift     831793131  9  1 Bf  -     -     -         1410    5    0 
swift     831793185  9  9 c   c     f     -         1405   30    0 
swift     831793229  9  8 c   r     b     c         1375   70    0 Jc Ts
swift     831793289  9  7 c   rc    c     c         1305  100    0 As 9s
swift     831793383  9  6 f   -     -     -         1205    0    0 
swift     831793452  9  5 f   -     -     -         1205    0    0 
swift     831793567 10  4 c   f     -     -         1205   10    0 
swift     831793655 11  3 f   -     -     -         1195    0    0 
swift     831793731 11  2 Bk  kf    -     -         1195   10    0 
swift     831793811 11  1 Bf  -     -     -         1185    5    0 
swift     831793921 11 11 f   -     -     -         1180    0    0 
swift     831794017 12 11 c   c     c     f         1180   50    0 
swift     831794163 12 10 f   -     -     -         1130    0    0 
swift     831794269 12  9 f   -     -     -         1130    0    0 
swift     831794355 12  8 c   rf    -     -         1130   30    0 
swift     831794420 12  7 f   -     -     -         1100    0    0 
swift     831794517 12  6 c   kf    -     -         1100   20    0 
swift     831794622 12  6 cc  k     f     -         1080   20    0 
swift     831794691 12  4 f   -     -     -         1060    0    0 
swift     831794778 12  3 f   -     -     -         1060    0    0 
swift     831794857 12  2 Bc  kc    kc    kc        1060   90  350 Jc Qh
swift     831794954 12  1 Bf  -     -     -         1320    5    0 
swift     831795016 12 12 c   rc    c     k         1315  110    0 Ts Ac
swift     831795146 12 11 f   -     -     -         1205    0    0 
swift     831795223 12 10 c   c     k     k         1205   20    0 Ah 6h
swift     831795311 12  9 f   -     -     -         1185    0    0 
swift     831795399 12  5 Q   -     -     -         1185    0    0 
swift     831960443  5  3 f   -     -     -         1185    0    0 
swift     831960500  5  2 Bk  b     b     -         1185   40   80 
swift     831960538  5  1 Bf  -     -     -         1225    5    0 
swift     831960581  5  5 f   -     -     -         1220    0    0 
swift     831960636  5  4 f   -     -     -         1220    0    0 
swift     831960678  5  3 f   -     -     -         1220    0    0 
swift     831960741  5  2 Bk  k     k     c         1220   30    0 Jc 3d
swift     831960778  5  1 Bf  -     -     -         1190    5    0 
swift     831960818  5  5 f   -     -     -         1185    0    0 
swift     831960849  5  4 f   -     -     -         1185    0    0 
swift     831960915  6  3 f   -     -     -         1185    0    0 
swift     831960942  6  2 Bk  k     b     bc        1185   70    0 8h 5h
swift     831960995  6  1 Bc  k     k     k         1115   10    0 9c 7s
swift     831961078  5  5 r   b     c     k         1105   50    0 Ac Kh
swift     831961141  6  5 r   b     k     b         1055   50  145 5h 5d
swift     831961210  7  4 c   k     kf    -         1150   10    0 
swift     831961277  8  3 f   -     -     -         1140    0    0 
swift     831961368  8  2 Bk  b     k     k         1140   20    0 3s 5c
swift     831961423  8  1 BfQ -     -     -         1120    5    0 
swift     832562336 10 10 f   -     -     -         1600    0    0 
swift     832562423 10  9 f   -     -     -         1600    0    0 
swift     832562495  9  7 f   -     -     -         1600    0    0 
swift     832562550  9  6 c   kc    cr    b         1600  100  296 Th Jd
swift     832562618  8  6 c   kf    -     -         1796   10    0 
swift     832562695  7  4 f   -     -     Q         1786    0    0 
swift     832565215 11  8 f   -     -     -         1786    0    0 
swift     832565300 11  7 f   -     -     -         1786    0    0 
swift     832565392 11  6 f   -     -     -         1786    0    0 
swift     832565482 12  5 f   -     -     -         1786    0    0 
swift     832565580 12  4 c   rc    c     b         1786   80  260 Ac As
swift     832565669 11  3 f   -     -     -         1966    0    0 
swift     832565845 11  2 Bk  c     cc    kc        1966   80  280 3h 3c
swift     832565926 10  1 Bf  -     -     -         2166    5    0 
swift     832566003 10 10 f   -     -     -         2161    0    0 
swift     832566085 10  9 c   rc    f     -         2161   40    0 
swift     832566177 12  8 f   -     -     -         2121    0    0 
swift     832566365 12  7 r   kc    krr   b         2121  130  345 Js As
swift     832566496 12  6 f   -     -     -         2336    0    0 
swift     832566567 12  5 f   -     -     -         2336    0    0 
swift     832566666 12  4 f   -     -     -         2336    0    0 
swift     832566820 12  3 f   -     -     -         2336    0    0 
swift     832566962 11  2 Bc  b     b     -         2336   60  225 
swift     832567048 12  1 Bc  kf    Q     -         2501   20    0 
swift     832637026 12  2 Bf  -     -     -         3751   10    0 
swift     832637138 11  1 Bf  -     -     -         3741    5    0 
swift     832637282 12 12 f   -     -     -         3736    0    0 
swift     832637460  9  8 f   -     -     -         3736    0    0 
swift     832637626 12 10 rc  cc    f     -         3736   80    0 
swift     832637781 11  8 f   -     -     -         3656    0    0 
swift     832637939 12  8 f   -     -     -         3656    0    0 
swift     832638051 11  6 f   -     -     -         3656    0    0 
swift     832638190  9  5 f   -     -     -         3656    0    0 
swift     832638263  9  5 f   -     -     -         3656    0    0 
swift     832638381  9  4 c   b     kc    kc        3656   60    0 Ah Ts
swift     832638465  8  3 c   b     k     b         3596   40  110 
swift     832638534  9  2 Bk  k     k     k         3666   10   50 Qs 8d
swift     832638603 10  1 Bc  k     b     b         3706   50  160 
swift     832638657 11 11 f   -     -     -         3816    0    0 
swift     832638723 10  9 r   k     c     c         3816   70    0 Jh Jc
swift     832638795 10  8 f   -     -     -         3746    0    0 
swift     832638886 10  8 f   -     -     -         3746    0    0 
swift     832639019  9  6 f   -     -     -         3746    0    0 
swift     832639110  9  5 c   b     b     bc        3746   80    0 Jd Kd
swift     832639232  8  4 f   -     -     -         3666    0    0 
swift     832639279 10  3 f   -     -     -         3666    0    0 
swift     832639395 12  2 Brc k     kc    kf        3666   60    0 
swift     832639521 12  1 Bf  -     -     -         3606    5    0 
swift     832639629 12 12 r   k     cc    f         3601   60    0 
swift     832639786 11 10 f   -     -     -         3541    0    0 
swift     832639871 12 10 f   -     -     -         3541    0    0 
swift     832640010 11  8 f   -     -     -         3541    0    0 
swift     832640074 12  8 f   -     -     -         3541    0    0 
swift     832640150 12  7 f   -     -     -         3541    0    0 
swift     832640319  9  4 cc  bc    bc    cf        3541  100    0 
swift     832640474 10  4 f   -     -     -         3441    0    0 
swift     832640521  8  2 fQ  -     -     -         3441    0    0 
