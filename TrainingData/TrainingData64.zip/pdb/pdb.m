m         984809788  3  2 Bk  bc    k     kf        1000   30    0 
m         984809836  2  1 Brc bc    brc   bf         970  150    0 
m         984809878  2  2 B   -     -     -          820   10   15 
m         984809882  2  1 Bf  -     -     -          825    5    0 
m         984809886  2  2 Brr c     rr    rf         820  170    0 
m         984809923  2  1 Brc brc   k     bf         650   90    0 
m         984809956  2  2 Bc  b     -     -          560   30   50 
m         984809970  2  1 Brr krr   brc   brc        580  240    0 Jc 3h
m         984810015  2  2 Brc rc    rr    f          340  150    0 
m         984810055  2  1 Brr br    k     kf         190   70    0 
m         984810088  2  2 Brc r     k     f          120   60    0 
m         984810110  2  1 Brr bcA   -     -           60   60  120 Ac 8h
m         984810125  2  2 Bc  rr    rcA   -          120  120    0 Th 4c
