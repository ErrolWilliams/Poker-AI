cc        808602313 10  9 c   c     c     f         1530   70    0 
cc        808602441  9  8 cc  c     c     c         1460   70    0 Qd Ac
cc        808602571  9  7 fQ  -     -     -         1390    0    0 
cc        808652268  6  2 Bc  c     c     f         1390   50    0 
cc        808652377  4  1 Bcr b     b     k         1340   60    0 5d 9s
cc        808652457  6  5 ccc cKQ   -     -         1280   60    0 
cc        808653183  7  2 Bk  kc    kc    kf        1220   50    0 
cc        808653334  7  1 Bc  kc    k     kcc       1170   90    0 As Jh
cc        808653551  7  7 c   c     c     r         1080  150    0 5s Qd
cc        808653749  7  6 c   k     k     k          930   10    0 3d 8s
cc        808653901  7  5 r   b     -     -          920   30   80 
cc        808653974  6  3 r   k     k     bc         970   60    0 Th Qh
cc        808654069  6  2 Bc  b     b     bc         910  100    0 8s 6c
cc        808654177  6  1 Bcrc kc    kf    -          810   50    0 
cc        808654385  6  6 c   b     k     b          760   40  100 6c Th
cc        808654553  6  5 c   c     c     rc         820  110    0 8s 9h
cc        808654704  6  4 c   kQ    -     -          710   10    0 
